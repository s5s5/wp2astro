        <footer style="margin-bottom: 20px;">
            <hr>
            <div class="row">
                <div class="col-md-6">
                    <a href="#top" data-scroll="true">
                        <i class="fa fa-arrow-up"></i> <?php _e('Back to top', 'gitsta'); ?>
                    </a>
                </div>
                <div class="col-md-6 text-right">
                    <small class="text-muted">
                        <?php printf(__('&copy <strong>%s</strong>', 'gitsta'), get_bloginfo('name')); ?></strong><br>
                        <?php printf(__('%s', 'gitsta'), '<a href="' . esc_url('http://www.miitbeian.gov.cn') . '" target="_blank">蜀ICP备16014041号-1</a>'); ?>
                    </small>
                </div>
            </div>
        </footer>
    </div>
    
    <?php wp_footer(); ?>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';        
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-53081-1', 'auto');
  ga('send', 'pageview');

</script>
</body>
</html>
