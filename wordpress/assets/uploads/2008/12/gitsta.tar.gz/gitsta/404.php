<?php get_header(); ?>

<div class="container">
    <div class="text-center">
        <h2><?php echo get_gitsta_theme_option('error_404_title'); ?></h2>
        <?php echo get_gitsta_theme_option('error_404_content'); ?>
    </div>

<script type="text/javascript">
	jQuery.getScript("https://qzone.qq.com/gy/404/data.js", function () {
		var max = jsondata.data.length;
		var num = Math.round(Math.random() * max);
		var picUrl = jsondata.data[num].child_pic;
		var moreUrl = jsondata.data[num].url;
		var more = ' <a href="' + moreUrl + '" target="_blank">查看详情</a>';
		var name = '<strong>' + jsondata.data[num].name + '</strong>';
		var sex = '（' + jsondata.data[num].sex + "）" + '，';
		var birthTime = '出生日期：' + jsondata.data[num].birth_time + '，';
		var lostTime = '失踪时间：' + jsondata.data[num].lost_time + '，';
		var lostPlace = '失踪地点：' + jsondata.data[num].lost_place + '，';
		var childFeature = '失踪人特征描述：' + jsondata.data[num].child_feature;

		$('h2').text("你访问的页面找不回来了，但是我们可以一起寻找失踪宝贝");
		$('.img-responsive').attr("src", picUrl);
		$('p.text-muted').addClass('text-left').html(name + sex + birthTime + lostTime + lostPlace + childFeature + more);
	});
	function GetQueryString(name) {
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if (r != null) return unescape(r[2]);
		return null;
	}
	if (GetQueryString('id') !== null) {
		location.pathname = GetQueryString('id');
	}
</script>


<?php get_footer(); ?>
