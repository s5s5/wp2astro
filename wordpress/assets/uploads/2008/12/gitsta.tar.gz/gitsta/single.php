<?php get_header(); ?>
    <div class="subhead">
        <div class="container">
            <h1><small><a href="<?php echo home_url(); ?>"><i class="fa fa-chevron-left"></i></a></small> <?php the_title(); ?></h1>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <?php while ( have_posts() ) : the_post(); ?>

                    <?php
                    get_template_part('content', 'single');
                    ?>
<div style="overflow: hidden;">
    <div style="float: left; width: 50%;"><?php if (get_previous_post()) { previous_post_link('上一篇: %link');} else {echo "没有了，已经是最后文章";} ?></div>
    <div style="float: right; width: 50%; text-align: right;"><?php if (get_next_post()) { next_post_link('下一篇: %link');} else {echo "没有了，已经是最新文章";} ?></div>
</div>
                    <div class="text-right">
                    <?php
                    // Pagination
                    gitsta_wp_link_pages();
                    ?>
                    </div>

                    <?php
                    // Comments
                    if(comments_open() || get_comments_number() != '0') {
                        comments_template();
                    }
                    ?>

                <?php endwhile; ?>
            </div>
            <div class="col-md-2">
                <?php get_sidebar(); ?>
            </div>
        </div>
<?php get_footer(); ?>