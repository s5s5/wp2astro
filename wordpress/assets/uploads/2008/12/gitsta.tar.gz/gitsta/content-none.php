<div class="text-center">
    <h3><?php _e('Nothing to see here.', 'gitsta'); ?><br>
    <small><?php _e('Move along folks!', 'gitsta'); ?></small></h3>
</div>